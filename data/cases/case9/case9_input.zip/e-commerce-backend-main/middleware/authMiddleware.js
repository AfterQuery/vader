import JWT from 'jsonwebtoken';
import userModels from "../models/userModels.js";

export const requestSignIn = async(req,res,next)=>{
    try {
        const decode = JWT.verify(req.headers.authorization, process.env.SECRET_KEY);
        req.user = decode
        next();
    } catch (error) {
        console.log(error);
    }
}

export const adminAccess = async(req,res,next)=>{
    try {
        const user = await userModels.findById(req.user._id);
        if(user.role !== 1){
            return res.status(401).send({
                success: false,
                massage: "You are not authorized to access this route"
            });
        }else{
            next();
        }
    } catch (error) {
        console.log(error);
        return res.status(500).send({
            success:false,
            massage:'Error in admin middleware',
            error
        })
    }
}